//******************************************/
// BE3029 - Electronica Digital 2
// 26/09/2025
// Laboratorio 6 - UART
// MCU: ESP32 dev kit 1.0
//******************************************/

//******************************************/
// Librerias
//******************************************/
#include <Arduino.h>
#include <stdint.h>
#include <LiquidCrystal.h>

//******************************************/
// Definiciones
//******************************************/

// Pines LCD (modo 4 bits)
#define RS 22
#define EN 23
#define D4 12
#define D5 14
#define D6 27
#define D7 26

// Potenciómetros
#define POT1 35   // Rojo
#define POT2 34   // Verde

// LED
#define LED_R 18
#define LED_G 19
#define LED_B 21

//******************************************/
// Variables globales
//******************************************/
LiquidCrystal lcd(RS, EN, D4, D5, D6, D7);

int valorRojo = 0;
int valorVerde = 0;
uint8_t contadorAzul = 0;  // Intensidad azul (0–255)

//******************************************/
// Prototipos
//******************************************/
void inicializarLCD();
void mostrarValores(int rojo, int verde, int azul);
void leerUART();

//******************************************/
// Configuración
//******************************************/
void setup() {
  Serial.begin(115200);

  // Inicializar LCD en 4 bits
  inicializarLCD();

  // Configuración de PWM
  ledcAttachPin(LED_R, 0);  
  ledcAttachPin(LED_G, 1);  
  ledcAttachPin(LED_B, 2);  

  ledcSetup(0, 5000, 8); 
  ledcSetup(1, 5000, 8);
  ledcSetup(2, 5000, 8);

}

//******************************************/
// Loop principal
//******************************************/
void loop() {
  // Lectura potenciómetros
  int lectura1 = analogRead(POT1);
  int lectura2 = analogRead(POT2);

  valorRojo  = map(lectura1, 0, 4095, 0, 255);
  valorVerde = map(lectura2, 0, 4095, 0, 255);

  // Actualizar contador azul desde UART
  leerUART();

  // Enviar valores a la terminal
  Serial.print("Rojo: ");
  Serial.print(valorRojo);
  Serial.print("  Verde: ");
  Serial.print(valorVerde);
  Serial.print("  Azul: ");
  Serial.println(contadorAzul);

  // Mostrar en LCD
  mostrarValores(valorRojo, valorVerde, contadorAzul);

  // Aplicar PWM a LEDs
  ledcWrite(0, valorRojo);
  ledcWrite(1, valorVerde);
  ledcWrite(2, contadorAzul);

  delay(300);
}

//******************************************/
// Otras funciones
//******************************************/
void inicializarLCD() {
  lcd.begin(16, 2);   
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("R: V: A:");
}

void mostrarValores(int rojo, int verde, int azul) {
  // Limpiar línea de valores
  lcd.setCursor(0, 1);
  lcd.print("                ");

  // Rojo
  lcd.setCursor(0, 1);
  lcd.print(rojo);

  // Verde
  lcd.setCursor(6, 1);
  lcd.print(verde);

  // Azul
  lcd.setCursor(12, 1);
  lcd.print(azul);
}

void leerUART() {
  if (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '+') {
      if (contadorAzul < 255) contadorAzul++;
    } else if (c == '-') {
      if (contadorAzul > 0) contadorAzul--;
    }
  }
}
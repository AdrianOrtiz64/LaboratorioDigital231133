//******************************************/
// BE3029 - Electronica Digital 2
// Laboratorio 4
// MCU: ESP32 dev kit 1.0
//******************************************/

#include <Arduino.h>
#include <stdint.h>
#include "driver/ledc.h"

// Definiciones
#define LED1 27
#define LED2 26
#define LED3 25

#define SERVO 33

#define BOTON1 13 // Mover servo a la derecha
#define BOTON2 12 // Mover servo a la izquierda
#define BOTON3 14 // Mostrar LEDs según posición

// Variables globales
const int freqServo = 50;
const int resolutionServo = 16;
const int canalServo = 3;

const uint16_t posiciones[5] = {
  1638,  // 0.5ms (0 grados)
  3277,  // 1.0ms (45 grados)
  4915,  // 1.5ms (90 grados)
  6553,  // 2.0ms (135 grados)
  8192   // 2.5ms (180 grados)
};

int posicionActual = 2; // centro

// Control de rebote
unsigned long tiempoBoton1 = 0;
unsigned long tiempoBoton2 = 0;
unsigned long tiempoBoton3 = 0;
const unsigned long debounceDelay = 200;

// Estados de botones
bool boton1Presionado = false;
bool boton2Presionado = false;
bool boton3Presionado = false;

// Prototipos de funciones
void moverDerecha();
void moverIzquierda();
void mostrarLeds();
void apagarLeds();

void setup() {
  ledcSetup(canalServo, freqServo, resolutionServo);
  ledcAttachPin(SERVO, canalServo);
  ledcWrite(canalServo, posiciones[posicionActual]);

  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);
  pinMode(LED3, OUTPUT);
  digitalWrite(LED1, LOW);
  digitalWrite(LED2, LOW);
  digitalWrite(LED3, LOW);

  pinMode(BOTON1, INPUT_PULLUP);
  pinMode(BOTON2, INPUT_PULLUP);
  pinMode(BOTON3, INPUT_PULLUP);
}

void loop() {
  // Verificar botón 1 (derecha)
  if (digitalRead(BOTON1) == LOW) {
    if (!boton1Presionado && millis() - tiempoBoton1 > debounceDelay) {
      moverDerecha();
      tiempoBoton1 = millis();
      boton1Presionado = true;
      apagarLeds();
    }
  } else {
    boton1Presionado = false;
  }

  // Verificar botón 2 (izquierda)
  if (digitalRead(BOTON2) == LOW) {
    if (!boton2Presionado && millis() - tiempoBoton2 > debounceDelay) {
      moverIzquierda();
      tiempoBoton2 = millis();
      boton2Presionado = true;
      apagarLeds();
    }
  } else {
    boton2Presionado = false;
  }

  // Verificar botón 3 (Accionar led)
  if (digitalRead(BOTON3) == LOW) {
    if (!boton3Presionado && millis() - tiempoBoton3 > debounceDelay) {
      mostrarLeds();
      tiempoBoton3 = millis();
      boton3Presionado = true;
    }
  } else {
    boton3Presionado = false;
  }
}

// Funciones externas
void moverDerecha() {
  if (posicionActual < 4) {
    posicionActual++;
    ledcWrite(canalServo, posiciones[posicionActual]);
  }
}

void moverIzquierda() {
  if (posicionActual > 0) {
    posicionActual--;
    ledcWrite(canalServo, posiciones[posicionActual]);
  }
}

void apagarLeds() {
  digitalWrite(LED1, LOW);
  digitalWrite(LED2, LOW);
  digitalWrite(LED3, LOW);
}

void mostrarLeds() {
  apagarLeds();
  switch(posicionActual) {
    case 1:
      digitalWrite(LED1, HIGH);
      break;
    case 2:
      digitalWrite(LED2, HIGH);
      break;
    case 3:
      digitalWrite(LED3, HIGH);
      break;
    default:
      break;
  }
}
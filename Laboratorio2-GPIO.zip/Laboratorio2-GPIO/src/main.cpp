#include <Arduino.h>
#include <stdint.h>

// Definiciones de pines 
#define LED_1 25
#define LED_2 26
#define LED_3 27
#define LED_4 14

#define BTN1 35  // Botón suma (pull-up interno)
#define BTN2 34  // Botón resta (pull-down externo)
#define BTN3 32  // Botón cambio de modo (pull-up interno)

// Prototipos de funciones 
void actualizarled(uint8_t valor);
void manejarBotones(void);

// Variables globales 
uint8_t contador = 0;  // posición del LED (0-3)
bool modoBinario = false; // false = modo lineal, true = modo binario

bool estadoAnteriorBtn1 = HIGH;
bool estadoAnteriorBtn2 = HIGH;
bool estadoAnteriorBtn3 = HIGH;
bool estadoActualBtn1 = HIGH;
bool estadoActualBtn2 = HIGH;
bool estadoActualBtn3 = HIGH;

unsigned long ultimaLecturaBtn1 = 0;
unsigned long ultimaLecturaBtn2 = 0;
unsigned long ultimaLecturaBtn3 = 0;

const unsigned long tiempoDebounce = 50; 

void setup() {
  pinMode(LED_1, OUTPUT);
  pinMode(LED_2, OUTPUT);
  pinMode(LED_3, OUTPUT);
  pinMode(LED_4, OUTPUT);

  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BTN2, INPUT_PULLDOWN);
  pinMode(BTN3, INPUT);

  // Inicializar con primer LED encendido
  actualizarled(contador);
}

void loop() {
  manejarBotones();
}

void actualizarled(uint8_t valor) {
  digitalWrite(LED_1, LOW);
  digitalWrite(LED_2, LOW);
  digitalWrite(LED_3, LOW);
  digitalWrite(LED_4, LOW);
  
  if(modoBinario) {
    // Modo binario - mostrar representación binaria
    digitalWrite(LED_1, (valor & 0x01) ? HIGH : LOW);
    digitalWrite(LED_2, (valor & 0x02) ? HIGH : LOW);
    digitalWrite(LED_3, (valor & 0x04) ? HIGH : LOW);
    digitalWrite(LED_4, (valor & 0x08) ? HIGH : LOW);
  } else {
    // Modo lineal - un solo LED encendido
    switch(valor % 4) {  // Asegurar que siempre sea 0-3
      case 0: digitalWrite(LED_1, HIGH); break;
      case 1: digitalWrite(LED_2, HIGH); break;
      case 2: digitalWrite(LED_3, HIGH); break;
      case 3: digitalWrite(LED_4, HIGH); break;
    }
  }
}

void manejarBotones(void) {
  unsigned long tiempoActual = millis();
  bool lecturaBtn1 = digitalRead(BTN1);
  bool lecturaBtn2 = digitalRead(BTN2);
  bool lecturaBtn3 = digitalRead(BTN3);

  // Procesar botón 1 (suma - pull-up)
  if (lecturaBtn1 != estadoAnteriorBtn1) {
    ultimaLecturaBtn1 = tiempoActual;
  }
  
  if ((tiempoActual - ultimaLecturaBtn1) > tiempoDebounce) {
    if (lecturaBtn1 != estadoActualBtn1) {
      estadoActualBtn1 = lecturaBtn1;
      if (estadoActualBtn1 == LOW) {
        if(modoBinario) {
          contador = (contador + 1) % 16;  // 0-15 en modo binario
        } else {
          contador = (contador + 1) % 4;   // 0-3 en modo lineal
        }
        actualizarled(contador);
      }
    }
  }
  estadoAnteriorBtn1 = lecturaBtn1;

  // Procesar botón 2 (resta - pull-down)
  if (lecturaBtn2 != estadoAnteriorBtn2) {
    ultimaLecturaBtn2 = tiempoActual;
  }
  
  if ((tiempoActual - ultimaLecturaBtn2) > tiempoDebounce) {
    if (lecturaBtn2 != estadoActualBtn2) {
      estadoActualBtn2 = lecturaBtn2;
      if (estadoActualBtn2 == HIGH) {
        if(modoBinario) {
          contador = (contador == 0) ? 15 : contador - 1;  // 15←0 en modo binario
        } else {
          contador = (contador == 0) ? 3 : contador - 1;   // 3←0 en modo lineal
        }
        actualizarled(contador);
      }
    }
  }
  estadoAnteriorBtn2 = lecturaBtn2;

  // Procesar botón 3 (cambio de modo - pull-up)
  if (lecturaBtn3 != estadoAnteriorBtn3) {
    ultimaLecturaBtn3 = tiempoActual;
  }
  
  if ((tiempoActual - ultimaLecturaBtn3) > tiempoDebounce) {
    if (lecturaBtn3 != estadoActualBtn3) {
      estadoActualBtn3 = lecturaBtn3;
      if (estadoActualBtn3 == LOW) {
        modoBinario = !modoBinario; // Cambiar modo
        contador = 0; // Resetear contador
        actualizarled(contador);
      }
    }
  }
  estadoAnteriorBtn3 = lecturaBtn3;
}
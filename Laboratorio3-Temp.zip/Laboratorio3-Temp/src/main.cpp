#include <Arduino.h>
#include <stdint.h>

// Definiciones de pines
#define LED_1 25
#define LED_2 26
#define LED_3 27
#define LED_4 14

#define LED_5 32
#define LED_6 33
#define LED_7 13
#define LED_8 12

#define ALARM_LED 23  // LED indicador de alarma
#define BTN1 35       // Botón suma (pull-up interno)
#define BTN2 34       // Botón resta (pull-down externo)
#define BTN3 39       // Botón capacitivo (reinicia timer)

// Variables globales
volatile uint8_t contadorManual = 0;
volatile uint8_t contadorAuto = 0;
volatile bool btn1Pressed = false;
volatile bool btn2Pressed = false;
volatile bool btn3Pressed = false;
volatile bool timerEvent = false;
bool alarmState = false;  // Estado del LED de alarma

// Prototipos de funciones
void actualizarLedsManual(uint8_t valor);
void actualizarLedsAuto(uint8_t valor);
void checkAlarmCondition();
void handleCapacitiveButton();

// Configuración del temporizador en 250ms
const uint64_t timerInterval = 250000; 
hw_timer_t *timer = NULL;

void IRAM_ATTR onTimer() {
  timerEvent = true;
}

void IRAM_ATTR handleBtn1() {
  static unsigned long lastInterruptTime = 0;
  static bool btnState = HIGH;
  unsigned long interruptTime = millis();
  
  bool currentState = digitalRead(BTN1);
  
  if (currentState != btnState) {
    if (interruptTime - lastInterruptTime > 50) {
      if (currentState == LOW) {
        btn1Pressed = true;
      }
      btnState = currentState;
      lastInterruptTime = interruptTime;
    }
  }
}

void IRAM_ATTR handleBtn2() {
  static unsigned long lastInterruptTime = 0;
  static bool btnState = LOW;
  unsigned long interruptTime = millis();
  
  bool currentState = digitalRead(BTN2);
  
  if (currentState != btnState) {
    if (interruptTime - lastInterruptTime > 50) {
      if (currentState == HIGH) {
        btn2Pressed = true;
      }
      btnState = currentState;
      lastInterruptTime = interruptTime;
    }
  }
}

void IRAM_ATTR handleBtn3() {
  static unsigned long lastInterruptTime = 0;
  unsigned long interruptTime = millis();
  
  if (interruptTime - lastInterruptTime > 50) {
    btn3Pressed = true;
    lastInterruptTime = interruptTime;
  }
}

void setup() {
  // Configurar LEDs manuales (1-4)
  pinMode(LED_1, OUTPUT);
  pinMode(LED_2, OUTPUT);
  pinMode(LED_3, OUTPUT);
  pinMode(LED_4, OUTPUT);
  
  // Configurar LEDs automáticos (5-8)
  pinMode(LED_5, OUTPUT);
  pinMode(LED_6, OUTPUT);
  pinMode(LED_7, OUTPUT);
  pinMode(LED_8, OUTPUT);

  // Configurar LED de alarma
  pinMode(ALARM_LED, OUTPUT);
  digitalWrite(ALARM_LED, LOW);

  // Configurar botones con interrupciones
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BTN2, INPUT_PULLDOWN);
  pinMode(BTN3, INPUT); // Sensor capacitivo
  attachInterrupt(digitalPinToInterrupt(BTN1), handleBtn1, CHANGE);
  attachInterrupt(digitalPinToInterrupt(BTN2), handleBtn2, CHANGE);
  attachInterrupt(digitalPinToInterrupt(BTN3), handleBtn3, RISING); // Asumiendo que el sensor capacitivo produce un flanco ascendente

  // Inicializar timer
  timer = timerBegin(0, 80, true); // Timer 0, prescaler 80 (1MHz)
  timerAttachInterrupt(timer, &onTimer, true);
  timerAlarmWrite(timer, timerInterval, true);
  timerAlarmEnable(timer);

  // Estado inicial
  actualizarLedsManual(contadorManual);
  actualizarLedsAuto(contadorAuto);
}

void loop() {
  // Manejar contador manual
  if (btn1Pressed) {
    btn1Pressed = false;
    contadorManual = (contadorManual + 1) % 16;
    actualizarLedsManual(contadorManual);
  }

  if (btn2Pressed) {
    btn2Pressed = false;
    contadorManual = (contadorManual == 0) ? 15 : contadorManual - 1;
    actualizarLedsManual(contadorManual);
  }

  // Manejar botón capacitivo
  if (btn3Pressed) {
    btn3Pressed = false;
    contadorAuto = 0; // Reiniciar contador del timer
    actualizarLedsAuto(contadorAuto);
  }

  // Manejar contador automático
  if (timerEvent) {
    timerEvent = false;
    contadorAuto = (contadorAuto + 1) % 16;
    actualizarLedsAuto(contadorAuto);
    checkAlarmCondition(); // Verificar condición de alarma
  }
}

void checkAlarmCondition() {
  if (contadorAuto == contadorManual) {
    alarmState = !alarmState; // Alternar estado de la alarma
    digitalWrite(ALARM_LED, alarmState ? HIGH : LOW);
    contadorAuto = 0; // Reiniciar contador automático
  }
}

void actualizarLedsManual(uint8_t valor) {
  digitalWrite(LED_1, (valor & 0x01) ? HIGH : LOW);
  digitalWrite(LED_2, (valor & 0x02) ? HIGH : LOW);
  digitalWrite(LED_3, (valor & 0x04) ? HIGH : LOW);
  digitalWrite(LED_4, (valor & 0x08) ? HIGH : LOW);
}

void actualizarLedsAuto(uint8_t valor) {
  digitalWrite(LED_5, (valor & 0x01) ? HIGH : LOW);
  digitalWrite(LED_6, (valor & 0x02) ? HIGH : LOW);
  digitalWrite(LED_7, (valor & 0x04) ? HIGH : LOW);
  digitalWrite(LED_8, (valor & 0x08) ? HIGH : LOW);
}